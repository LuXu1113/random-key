This Java tools version was built from the bazel repository at commit hash 0c460ff8959027f8ccebe8d0bc76849348dcf3cc
using bazel version 2.1.0.
To build from source the same zip run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout 0c460ff8959027f8ccebe8d0bc76849348dcf3cc
$ bazel build //src:java_tools_java11.zip
